public abstract class Sorter {
    public abstract long sort(int[] nums);
}
