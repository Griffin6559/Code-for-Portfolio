package Casting;
public class casting {
    public static void main(String[] args) {
        float num=8;
        int num2 = (int) num;

        System.out.println(num);
        System.out.println(num2);

    }
}
