package coke;
import java.util.Scanner;

public class coke {
    public static void main(String[] args) {
        int amount_due = 50;
        System.out.println("Your amount due is 50 cents");
        Scanner coin_input=new Scanner(System.in);
        while (amount_due > 0){
            System.out.println("Input coin");
            int coin_value = coin_input.nextInt();

            if (coin_value == 25) {
                amount_due -= coin_value;
                if (amount_due<0){
                    System.out.println("Remaining amount due is 0 cents");
                }
                if (amount_due>0){
                    System.out.println("Remaining amount due is " + amount_due + " cents");
                }
            }
            else if(coin_value ==10) {
                amount_due -= coin_value;
                if (amount_due<0){
                    System.out.println("Remaining amount due is 0 cents");
                }
                if (amount_due>0){
                    System.out.println("Remaining amount due is " + amount_due + " cents");
                }
            }
            else if(coin_value==5) {
                amount_due -= coin_value;
                if (amount_due<0){
                    System.out.println("Remaining amount due is 0 cents");
                }
                if (amount_due>0){
                    System.out.println("Remaining amount due is " + amount_due + " cents");
                }
            }
                else {
                System.out.println ("Please input a coin with the value, 25, 10, or 5");

            }
            if (amount_due <=0) {
                System.out.println("Thank you for your purchase");
                break;
            }

        }
       coin_input.close();

    }
}
