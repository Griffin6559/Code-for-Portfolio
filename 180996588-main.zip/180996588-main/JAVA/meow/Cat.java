public class Cat {
    String name;
    String breed;
    boolean furry;

    public void speak(){
        System.out.println(name + " says Meow");
    }
    public void describe_cat(){
        System.out.println(name + " is a " + breed + ". She says Meow");
    }

    public static void main(String[] args) {
        Cat mycat=new Cat();
        mycat.name = "Clementine";
        mycat.breed="House cat";
        mycat.furry= true;
        mycat.describe_cat();
    }
}
