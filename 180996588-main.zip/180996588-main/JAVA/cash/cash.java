// package cash;

import java.util.Scanner;

public class cash {
    Scanner cost=new Scanner(System.in);
    private int quarters;
    private int dimes;
    private int nickels;
    private int pennies;
    private String totalCost;
    private int digits;
    private String dollars;
    private String cents;
    private int Dollars;
    private int Cents;
    private int maxDigits;
    private int remainder;


    public void amount() {
        System.out.println("What amount are you paying? (Please omit dollar sign)");
        totalCost = cost.nextLine();


        digits=totalCost.indexOf(".");
        maxDigits=totalCost.length();
        dollars=totalCost.substring(0, digits);
        cents = totalCost.substring(digits+1, maxDigits);



    }

    public void splitCoins(int Dollars,int Cents, int nickels, int quarters, int pennies, int dimes){
        Dollars=(Integer.parseInt(dollars)*100);
        Cents=Integer.parseInt(cents);

        quarters=((Dollars/25)+(Cents/25));
        remainder=((Dollars % 25)+(Cents % 25));

        dimes = (remainder/10);
        remainder=(remainder % 10);
        nickels = (remainder/5);
        remainder = (remainder % 5);
        pennies = remainder;

        System.out.println("Quarters: " + quarters);
        System.out.println("Dimes: " + dimes);
        System.out.println("Nickels: " + nickels);
        System.out.println("Pennies: " + pennies);
    }



    public void run() {
        amount();
        if (cents.length()>2){
            System.out.println("Please try again with a real price in the format of xx.xx");

        }
        else {
            splitCoins(Dollars, Cents, nickels, quarters, pennies, dimes);
            // amount();

        }


    }


    public static void main(String[] args) {
        cash price = new cash();
        price.run();
    }

}
