def main():
    time = input("What time is it? ")
    floatTime = convert(time)

    if floatTime >= 7.0:
        if floatTime <= 8.0:
            print ("Breakfast")

    if floatTime >= 12.0:
        if floatTime <= 13.0:
            print ("Lunch")

    if floatTime >= 18.0:
        if floatTime <= 19.0:
            print ("Dinner")

def convert(time):
    hour,minute = time.split(":")
    hourFloat = float(hour)
    min = float(minute)
    newTime = (min / 60)
    new2Time = (newTime + hourFloat)
    return (new2Time)

main()

