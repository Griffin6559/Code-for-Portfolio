def main():
    x,y,z = input("What would you like solved? ").split()
    integer1 = float(x)
    integer2 = float(z)

    if y == ("+"):
     answer = (integer1 + integer2)
     print (answer)

    if y == ("-"):
       answer = (integer1 - integer2)
       print (answer)

    if y == ("*"):
       answer = (integer1 * integer2)
       print (answer)

    if y == ("/"):
      answer = (integer1 / integer2)
      print (answer)

main()
