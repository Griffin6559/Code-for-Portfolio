def main():
    question = input("What is the answer to the Great Question of Life, the Universe and Everything? ")
    if question == "42" or question =="forty two" or question == "fort-two" or question == "Forty Two" or question == "Forty-Two":
        print("Yes")
    elif question:
        print("No")

main()
