def main():
    question = input("What is the name of the file? ")
    question = question.casefold()
    if question.endswith(".gif"):
        print("image/gif")
    if question.endswith(".jpg"):
        print("image/jpeg")
    if question.endswith(".jpeg"):
        print("image/jpeg")
    if question.endswith(".png"):
        print("image/png")
    if question.endswith(".pdf"):
        print("application/pdf")
    if question.endswith(".txt"):
        print("text/plain")
    if question.endswith(".zip"):
        print("application/zip")
    else:
        print("application/octet-stream")

main()
