def main():
    shopping_list = ["milk","pita","cheese"]
    shopping_list.append("potato")
    print(shopping_list[1])

    griffin = {"fantasy_name":"Griffin",
               "animal_names":"Eagle and Lion",
               "where_found":"mythology"}
    griffin["appearance"] = "head of an eagle, body of a lion"

    print(griffin["animal_names"])

main()
