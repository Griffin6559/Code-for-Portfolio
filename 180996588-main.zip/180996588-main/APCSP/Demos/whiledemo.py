from random import randint

def main():
    secret = randint(1,100)
    print("I'm thinking of a number between 1 and 100")
    while True:
        guess = int(input("What is you guess"))
        if guess < secret:
            print ("Your guess is too low")
        elif guess > secret:
            print ("Your guess is too high")
        else:
            print ("You got it!")
            break
            print ("Thanks for playing!")

main()
