def main():
  my_string = "welcome to AP computer Science Principles"
  print(f"The length of my_string is {len(my_string)}")


    #iteration with numbers
  for i in range(len(my_string)):
    print(my_string[i])

    #iteration with elements
    total = 0
    for c in my_string:
      if c == "c" or c == "C":
        #total = total + 1 is the same as total += 1
        total += 1
    print(f"There are {total} c's in my_string")

main()
