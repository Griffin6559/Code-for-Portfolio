from termcolor import colored
from random import choice

def main():
   f = open("secrets.txt", 'r')
   secretlist = f.readlines()
   secret = choice(secretlist)
   print (secret)
   corect = secret
   guess = input("What is your guess? ")
   one,two,three,four,five = [x for x in guess]
   for i in range(len(guess)):
      if(guess[i]) in corect:
        how_correct = (colored(guess,'green'))

   print(how_correct)

main()
