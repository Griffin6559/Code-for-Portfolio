def main():
    print("Your coke will cost 50 cents.")
    amount_due = 50
    while True:
        coin = int(input("Insert your coin "))
        if coin == (25):
            amount_due = (amount_due - coin)
        if coin == (10):
            amount_due = (amount_due - coin)
        if coin == (5):
            amount_due = (amount_due - coin)
        if amount_due >0:
            print(f"Amount due: {amount_due}")
        if amount_due == 0:
            print ("Your purchase is complete")
            break
        if amount_due < 0:
            change = (0 - amount_due)
            print(f"Your change is {change}")
            print ("Your purchase is complete")
            break

        elif coin not in [25, 5, 10]:
            print ("That is not a coin I can accept")






main()
