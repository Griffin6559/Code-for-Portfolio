def main():
    desired_fruit = input("What fruit would you like to be granted knowledge about? ")
    desired_fruits = desired_fruit.lower()
    fruits = [
        {"fruit": "apple", "portion_size": "portion size: 242 grams", "calories": "130 calories", "iron":"iron: 2%"},
        {"fruit": "avocado", "portion_size": "portion size: 30 grams", "calories": "50 calories", "iron":"iron: 2%"},
        {"fruit":"banana", "portion_size": "portion size: 126 grams", "calories": "110 calories", "iron": "iron: 2%"},
        {"fruit": "cataloupe", "portion_size": " portion size: 134 grams", "calories": "50 calories", "iron": "iron: 2%"},
        {"fruit": "grapefruit", "portion_size": "portion size: 154 grams", "calories": "60 calories", "iron": "iron: 0%"},
        {"fruit": "grapes", "portion_size": "portion size: 126 grams", "calories": "90 calories", "iron": "iron: 0%"},
        {"fruit": "honeydew melon","portion_size": "portion size: 134 grams", "calories": "50 calories", "iron":"iron: 2%"},
        {"fruit": "kiwifruit", "portion_size": "portion size: 148 grams", "calories": "90 calories", "iron": "iron: 2%"},
        {"fruit": "lemon", "portion_size": "portion size: 58 grams", "calories": "15 calories", "iron": "iron: 0%"},
        {"fruit": "lime", "portion_size": "portion size: 67 grams", "calories": "20 calories", "iron": "iron: 0%"},
        {"fruit": "nectarine", "portion_size": "portion size: 140 grams", "calories": "60 calories", "iron": "iron: 2%"},
        {"fruit": "orange", "portion_size": "portion size: 154 grams", "calories": "80 calories", "iron": "iron: 0%"},
        {"fruit": "peach", "portion_size": "portion size: 147 grams", "calories": "60 calories", "iron": "iron: 2%"},
        {"fruit": "pear", "portion_size": "portion size: 166 grams", "calories": "100 calories", "iron": "iron: 0%"},
        {"fruit": "pineapple", "portion_size": "portion size: 112 grams", "calories": "50 calories","iron": "iron: 2%"},
        {"fruit": "plums", "portion_size": "portion size: 151 grams", "calories": "70 calories", "iron": "iron: 2%"},
        {"fruit": "strawberries", "portion_size": "portion size: 147 grams", "calories": "50 calories", "iron": "iron: 2%"},
        {"fruit": "sweet cherries", "portion_size": "portion size: 140 grams", "calories": "100 calories", "iron": "iron: 2%"},
        {"fruit": "tangerine", "portion_size": "portion size: 109 grams", "calories": "50 calories", "iron": "iron: 0%"},
        {"fruit": "watermelon", "portion_size": "portion size: 280 grams", "calories": "80 calories", "iron": "iron: 4%"}
            ]

    for fruit in fruits:
        if fruit["fruit"] == desired_fruits:
            print(fruit["fruit"])
            print(fruit["portion_size"])
            print(fruit["calories"])
            print(fruit["iron"])

main()
