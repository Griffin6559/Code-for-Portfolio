def main():
    question = input("What would you like to say? ")
    counting = question.count("a")
    counting1 = question.count("e")
    counting2 = question.count("o")
    counting3 = question.count("u")
    counting4 = question.count("i")
    total = (counting + counting1 + counting2 + counting3 + counting4)

    print (total)

main()
