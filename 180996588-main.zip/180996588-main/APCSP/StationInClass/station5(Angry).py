def main():
    question = input("What are you mad about? ")
    angry = question.upper()
    print (angry)

main()
