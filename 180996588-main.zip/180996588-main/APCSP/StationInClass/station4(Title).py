def main():
    question = input("What is your topic? ")
    print (f"---- {question} ----")

main()
