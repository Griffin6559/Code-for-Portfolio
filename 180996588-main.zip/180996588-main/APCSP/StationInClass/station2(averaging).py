def main():
    x,y,z = input("What are your three numbers? ").split()
    print(answer2)

def calculations():
    integer1 = float(x)
    integer2 = float(y)
    integer3 = float(z)

    answer = (x + y + z)
    answer2 = (answer)/3
    return answer2

calculations()
main()
