def main():
    name = "Mark Sobkowicz"
    print(name.upper().lower())
    print(name.lower().upper())

main()
