def main():
    a = 7
    b = a
    c = b
    a = 4
    print(a + b + c)

main()
