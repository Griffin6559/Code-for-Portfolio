def main():
    text=input("What code would you like to decrypt")
    

main()
