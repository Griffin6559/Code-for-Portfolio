import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    user_id= session["user_id"]
    portfolio=[]
    tickers= db.execute("SELECT DISTINCT ticker FROM transactions WHERE user_id=?", user_id)
    cash= db.execute("SELECT cash FROM users WHERE id=?", user_id)
    total_stock_val=0
    cash_amount = cash[0]['cash'] if cash else 0

    for ticker in tickers:

        symbol= (ticker["ticker"])
        ticker_symbol=lookup(symbol)

        sum=db.execute("SELECT SUM (shares) FROM transactions WHERE user_id=? AND ticker=?", user_id, symbol)
        sum_all = db.execute("SELECT SUM (shares) FROM transactions WHERE user_id=?", user_id)
        sum_all_number=(sum_all[0]['SUM (shares)'] or 0)
        ticker_p_all = (ticker_symbol["price"])
        total_stock_val= (float(sum_all_number)*float(ticker_p_all))
        ticker_price = (ticker_symbol["price"])
        sum_amount = (sum[0]['SUM (shares)'] or 0)
        current_value= (float(ticker_price) * float(sum_amount))
        entry={'symbol':symbol, 'shares':sum_amount, 'pps': ticker_price, 'current_value': current_value}
        portfolio.append(entry)
    total_account_val=(total_stock_val + cash_amount)

    """Show portfolio of stocks"""
    return render_template("index.html", portfolio=portfolio, cash_amount=cash_amount, total_stock_val=total_stock_val, total_account_val=total_account_val)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    user_id= session["user_id"]
    cash = db.execute("SELECT cash FROM users WHERE id=?", user_id)
    cash_number = float(cash[0]['cash'])


    """Buy shares of stock"""
    if request.method =="GET":
        return render_template("buy.html", cash=cash_number,)
    if request.method == "POST":
        symbol=lookup(request.form.get("symbol"))
        shares=request.form.get("shares")
        new_cash=(cash_number - (symbol["price"]*float(shares)))

        if cash_number < (symbol["price"]*float(shares)):
            flash("You don't have enough money")
            return redirect("/buy")

        db.execute("UPDATE users SET cash=? WHERE id=?", new_cash, user_id)
        db.execute ("INSERT INTO transactions(ticker, pps, shares, user_id, timestamp) VALUES (?,?,?,?, CURRENT_TIMESTAMP)", symbol["symbol"], symbol["price"], shares, user_id)

        return render_template("bought.html", symbol=symbol, new_cash=new_cash)




@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":
        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute(
            "SELECT * FROM users WHERE username = ?", request.form.get("username")
        )

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(
            rows[0]["hash"], request.form.get("password")
        ):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""
    if request.method == "GET":
        return render_template("quote.html")
    if request.method=="POST":
        symbol = lookup(request.form.get("symbol"))

        if not symbol:
            flash("That is not a ticker")
            return render_template("quote.html")
        else:
            return render_template("quoted.html", symbol = symbol)




@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""
    if request.method == "GET":
        return render_template("register.html")

    if request.method == "POST":
        username = request.form.get ("username")
        password = generate_password_hash(request.form.get("password"))
        confirmation = request.form.get("confirm_password")

        if not username or not request.form.get("password") or not confirmation:
            flash("Not all fields are filled out")
            return redirect("/register")

        if request.form.get("password") != confirmation:
            flash("Password are not equal")
            return redirect("/register")

        check = db.execute("SELECT * FROM users WHERE username = ?", username)
        if check:
            flash("That username already exists")
            return redirect("/register")

        else:
            db.execute ("INSERT INTO users (username, hash) VALUES (?,?)", username, password)
            return redirect("/")



@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    user_id= session["user_id"]
    cash = db.execute("SELECT cash FROM users WHERE id=?", user_id)
    cash_number = float(cash[0]['cash'])
    if request.method =="GET":
        tickers= db.execute("SELECT DISTINCT ticker FROM transactions WHERE user_id=?", user_id)
        ticker_list=[]
        for ticker in tickers:
            symbols= (ticker["ticker"])
            ticker_addition={'ticker':symbols}
            ticker_list.append(ticker_addition)
        return render_template("sell.html", cash=cash_number, ticker_list=ticker_list, ticker_addition=ticker_addition)

    if request.method == "POST":
        symbol=lookup(request.form.get("symbol"))
        shares=float(request.form.get("shares"))
        new_cash=(cash_number + (symbol["price"]*float(shares)))
        db.execute("UPDATE users SET cash=? WHERE id=?", new_cash, user_id)
        db.execute ("INSERT INTO transactions (ticker, pps, shares, user_id, timestamp) VALUES (?,?,?,?, CURRENT_TIMESTAMP)", symbol["symbol"], symbol["price"], -shares, user_id)
        return render_template("sold.html", new_cash=new_cash)




    """Sell shares of stock"""
