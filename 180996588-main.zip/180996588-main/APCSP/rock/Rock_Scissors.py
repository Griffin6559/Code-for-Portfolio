from random import choice
def main():
    your_score = 0
    comp_score = 0

    while your_score <= 4 and comp_score <= 4:
        move = input("What is your move? Type in rock, paper, or scissors: ")
        moves = ["rock", "paper", "scissors"]
        play = choice(moves)
        print(play)
        winner = game(move,play)
        if winner == "you":
            your_score += 1
            print ("You win!")
            print (f"the current score is (you):{your_score} to (computer):{comp_score}")
        if winner == "computer":
            comp_score += 1
            print("You lost :( ")
            print (f"the current score is (you):{your_score} to (computer):{comp_score}")
        if winner == "none":
            print("You tied")
            print (f"the current score is (you):{your_score} to (computer):{comp_score}")

    if your_score == 5:
        print ("You won! Now the computer is sad, that isn't very nice of you... ")
    if comp_score == 5:
        print ("You lost! The computer was better this time, make sure to say something nice to it!")




def game(move, play):
    if move == play:
        winner = ("none")
        return winner
    if move == "rock":
        if play == "scissors":
            winner = ("you")
            return winner
    if move == "rock":
        if play == "paper":
            winner = ("computer")
            return winner
    if move == "paper":
        if play == "rock":
            winner = ("you")
            return winner
    if move == "paper":
        if play == "scissors":
            winner = ("computer")
            return winner
    if move == "scissors":
        if play == "rock":
            winner = ("computer")
            return winner
    if move == "scissors":
        if play == "paper":
            winner = ("you")
            return winner

main()
