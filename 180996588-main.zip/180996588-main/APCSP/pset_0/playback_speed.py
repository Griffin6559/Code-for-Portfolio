def main():
    say = input("Say your words here:")
    replace = say.replace(" ", "...")
    print(replace)

main()
