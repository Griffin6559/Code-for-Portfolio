def convert(answer):
     answer = answer.replace (":)","🙂")
     answer = answer.replace (":(","🙁")
     answer = answer.replace ("(:","🙂")
     answer = answer.replace ("):","🙁")
     return answer

def main():
    answer = input("How are you feeling today?")
    answer = convert(answer)
    print(answer)

main()
