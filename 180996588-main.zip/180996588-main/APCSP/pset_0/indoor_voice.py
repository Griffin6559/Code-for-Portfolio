def main():
    shouted = input("Shout something!")
    talked = shouted.casefold()
    print(talked)

main()
