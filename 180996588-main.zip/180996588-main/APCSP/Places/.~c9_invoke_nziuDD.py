import csv

with open('uszips.csv', mode='r') as csv_file:
    csv_reader = csv.DictReader(csv_file)
    line_count = 0
    places = []
    for row in csv_reader:
        if line_count == 0:
            print(f'Column names are {", ".join(row)}')
            line_count += 1
        else:
            place = {'zip': row['zip'], 'lat': row['lat'], 'lng' : row['lng'], 'city': row['city'] ,'state': row['state_id']}
            places.append(place)


def search_by_zip(zip):
    global places
    for place in places:
        if place['zip'] == zip:
            return place


def search_by_city(city):
    global places
    results = []
    for place in places:
        if place['city'] == city:
            results.append(place)
    return results

r = search_by_city("Lexington")
for p in r:
    print(p)



