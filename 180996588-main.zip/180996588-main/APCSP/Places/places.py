import csv
import requests

def get_places():
    with open('uszips.csv', mode='r') as csv_file:
        csv_reader = csv.DictReader(csv_file)
        line_count = 0
        places = []
        for row in csv_reader:
            if line_count == 0:
                #print(f'Column names are {", ".join(row)}')
                line_count += 1
            else:
                place = {'zip': row['zip'], 'lat': row['lat'], 'lng' : row['lng'], 'city': row['city'] ,'state': row['state_id']}
                places.append(place)
    return places


def search_by_zip(places, zipcode):
    for place in places:
        if place['zip'] == zipcode:
            return place
    return None

def display(place):
        print(f"{place['city']}, {place['state']}")


# def search_by_city(places, cityname, statecode):
#     for place in places:
#         if place['city'] == cityname:
#             if place['state'] == statecode:
#                 print(place['zip'])

def get_weather(place):
    lat = place['lat']
    lng = place['lng']
    url = f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lng}&current=temperature_2m&daily=weather_code,temperature_2m_max,temperature_2m_min,sunrise,sunset&temperature_unit=fahrenheit&wind_speed_unit=ms&precipitation_unit=inch&timezone=America%2FNew_York"
    response = requests.get(url)
    data = response.json()
    return data



def main():
    #this is your main program that interacts with the user.
    zipcode = input("What is the zipcode?")
    places = get_places()
    the_place = search_by_zip(places, zipcode)
    display(the_place)
    # cityname = input("What is the city?")
    # statecode = input("What is the state?")
    # city_search = search_by_city(places, cityname, statecode)
    data = get_weather(the_place)
    print (f"The sunrise today is {data['daily']['sunrise'][0][12:16]}am and the sunset is {data['daily']['sunset'][0][12:16]}")
    travel = input("Would you like to travel into the future (yes or no)?")
    if travel == "yes":
        how_far = input("How many days into the future would you like to go (one, two....six)?")
    if travel == "no":
        how_far = (f"Alright then, the sunrise today is still {data['daily']['sunrise'][0][12:16]}am and the sunset is {data['daily']['sunset'][0][12:16]}")
        print(how_far)
    if how_far == "one":
        print(f"You are now one day in the future. The sunrise today is {data['daily']['sunrise'][1][12:16]}am and the sunset is {data['daily']['sunset'][1][12:16]}")
    if how_far == "two":
        print(f"You are now two days in the future. The sunrise today is {data['daily']['sunrise'][2][12:16]}am and the sunset is {data['daily']['sunset'][2][12:16]}")
    if how_far == "three":
        print(f"You are now three days in the future. The sunrise today is {data['daily']['sunrise'][3][12:16]}am and the sunset is {data['daily']['sunset'][3][12:16]}")
    if how_far == "four":
        print(f"You are now four days in the future. The sunrise today is {data['daily']['sunrise'][4][12:16]}am and the sunset is {data['daily']['sunset'][4][12:16]}")
    if how_far == "five":
        print(f"You are now five days in the future. The sunrise today is {data['daily']['sunrise'][5][12:16]}am and the sunset is {data['daily']['sunset'][5][12:16]}")
    if how_far == "six":
        print(f"You are now six days in the future. The sunrise today is {data['daily']['sunrise'][6][12:16]}am and the sunset is {data['daily']['sunset'][6][12:16]}")





main()
