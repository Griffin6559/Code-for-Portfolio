import sys

def main():
    broken_up= sys.argv
    if float(len(broken_up)) !=2:
        print("Usage: python caesar.py key")
    if float(len(broken_up)) ==2:
        if (broken_up[1]).isdigit():
            plaintext=input("What is the text you want to encrypt?")
        if not (broken_up[1]).isdigit():
            print("Usage: python caesar.py key")
        key= (int(broken_up[1]))
        cyphertext=""
        for char in plaintext:
            encrypted= encrypt(char, key)
            cyphertext += encrypted
        print(cyphertext)


def encrypt(char, key):
    char=char
    key=key
    if char.isalpha():
        if char.islower():
            alphabet=("abcdefghijklmnopqrstuvwxyz")
            letter_number=alphabet.index(char)
            encrypted= (alphabet[(key+letter_number) %26])
            return encrypted
    if char.isalpha():
        if char.isupper():
            char=char.lower()
            alphabet=("abcdefghijklmnopqrstuvwxyz")
            letter_number=alphabet.index(char)
            encrypted= (alphabet[(key+letter_number) %26])
            encrypted=(encrypted.upper())
            return encrypted
    if not char.isalpha():
        return char



main()
