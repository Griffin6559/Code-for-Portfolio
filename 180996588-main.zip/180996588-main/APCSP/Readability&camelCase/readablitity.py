def main():
    text = input("Paste text here: ")
    letter = int(count_letters(text))
    words = int(count_words(text))
    sentences = int(count_sentences(text))
    L = (letter/words*100)
    S = (sentences/words*100)
    answer = (0.0588*L-0.296*S-15.8)
    answer = round(answer)

    if answer < 1:
        print("Before grade 1")
    elif answer > 1 and answer < 16:
        print (f"grade {answer}")
    if answer > 15:
        print("Grade 16+")


def count_letters(text):
    letter = 0
    for char in text:
        if char.isalpha():
            letter += 1
    return letter

def count_words(text):
    words = 1
    for char in text:
        if char.isspace():
            words += 1
    return words

def count_sentences(text):
    sentences = 0
    for char in text:
        if char == "." or char == "?" or char == "!":
            sentences += 1
    return sentences


main()
