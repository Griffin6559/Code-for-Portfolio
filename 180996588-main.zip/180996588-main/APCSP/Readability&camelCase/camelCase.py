

def main():
    name = input("Give me a name in camel case: ")
    name = convert(name)
    print(name)

def convert(name):
    for char in name:
        if char.isupper():
           name = name.replace(char,'_' + char.lower())
    return name

main()
