def main():
    print("Hello, World")
    name = input("What is your name?")
    print(f"Hello,{name}")

main()
