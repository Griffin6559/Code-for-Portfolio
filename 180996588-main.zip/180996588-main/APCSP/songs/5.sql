SELECT avg(energy)
FROM songs;
