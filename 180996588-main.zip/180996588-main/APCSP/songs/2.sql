SELECT name From songs
ORDER by tempo;
