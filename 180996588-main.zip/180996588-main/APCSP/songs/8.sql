SELECT name from songs
WHERE name LIKE '%feat%';
