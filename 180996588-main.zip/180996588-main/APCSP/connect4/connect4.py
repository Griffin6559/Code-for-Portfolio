import os
from time import sleep

def main():
    #this code is used to clear the terminal so that it does not become cluttered -- Note that it is only usable if 'os' is imported above
    clear()

    #take player names
    p1 = input("Player 1 Name: ")
    p2 = input("Player 2 Name: ")
    print(p1, p2, sep=" vs ")
    player_names = [p1, p2]

    #this code is used to make the program halt for a specified amount of time (in seconds) -- Note that it is only usable if 'time' is imported above
    sleep(1)

    clear()

    #greet the players and add instructions if you would like
    greet()

    #initialize the board
    board = [
        [0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 0, 0, 0]
    ]
    current_player = 1
    winner = 0
    #begin playing -- loops until game is won

    while True:
        clear()
        #draw the current state of the board
        draw(board)
        print()
        column = int(input(f"{player_names[current_player-1]}'s move: "))
        if move(board, column, current_player):
            current_player = (current_player % 2) + 1
        else:
            print("Illegal move.")
            sleep(2)
        #check for win
        winner = won(board)
        print()
        if winner != 0:
            draw(board)
            print()
            print(f"Player {winner} wins!.")
            sleep(5)
            break
        if tie(board):
            draw(board)
            print()
            print("Game Over.  No one wins.")
            sleep(5)
            break


#used to clear the screen to keep the terminal neat
def clear():
    os.system('clear')

#greets player at beginning of game
def greet():
    print("WELCOME TO CONNECT FOUR")
    sleep(2)
    clear()

#use your board variable to print the current state of the board
#you can use any symbols you want here - make it look good!
def draw(board):
    for row in[0,1,2,3,4,5]:
        print()
        for col in[0,1,2,3,4,5,6]:
            if board[row][col]==0:
                print("⚪", end="")
            if board[row][col] == 1:
                print("🔴", end="")
            if board[row][col] == 2:
                print("🔵", end="")

    return

#check if the column the player wants to place a token in is still available and not full
#then changes the appropriate value in board.
#returns True if a move is made, otherwise False
def move(board, column, player):
    for row in[5,4,3,2,1,0]:
        if board[row][column] == 0:
            board[row][column]=player
            return True
    else:
        return False

#check if either player has won the game.  Return either 0 (no one has won)
#or 1 or 2 if a player won.
def won(board):
    for row in[5,4,3,2,1,0]:
        for col in[0,1,2,3]:
            for player in[1,2]:
                if board[row][col]==player and board[row][col+1]==player and board [row][col+2]==player and board [row][col+3]== player:

                    return player
    for row in[5,4,3]:
        for col in[0,1,2,3,4,5,6]:
            for player in[1,2]:
                if board[row][col]== player and board[row-1][col]==player and board[row-2][col]==player and board[row-3][col]==player:
                    return player
    for row in[5,4,3,2,1,0]:
        for col in[0,1,2,3]:
            for player in[1,2]:
                if board[row][col]== player and board[row-1][col+1]==player and board[row-2][col+2]==player and board[row-3][col+3]==player:
                    return player

    for row in[5,4,3,2,1,0]:
        for col in[6,5,4,3]:
            for player in[1,2]:
                if board[row][col]== player and board[row-1][col-1]==player and board[row-2][col-2]==player and board[row-3][col-3]==player:
                    return player

    else: 
            return 0


#return True if the board is completely full.  Return False otherwise
def tie(board):
    for col in[0,1,2,3,4,5,6]:
        if board[0][col] == 0:
            return False


    return True


main()
